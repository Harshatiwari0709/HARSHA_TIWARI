#include <stdio.h>
int main(){
    char c='AB';
    int a=24,b=20;
    if((sizeof(a)+sizeof(b)+sizeof(c))> sizeof(int))
    {
        printf("can not be printed");
    }
        printf("\nsize of result set %ld",sizeof(a+b+c));
        //return 0;
    }