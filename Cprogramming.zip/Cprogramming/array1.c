/*  Working with an Array example */

//#include <stdio.h>

/*int main(void)
{
	int values[10];
	int index;

	values[0] = 197;
	values[2] = -100;
	values[5] = 350;
	values[3] = values[0] + values[5];
	values [9] = 
	values[5] / 10;
	--values[2];

	for (index = 0; index < 10; ++index)
		printf("values[%i] = %i\n", index, values[index]);

	return 0;
}*/

/*#include <stdio.h>

int main(void)
{
	int ratingCounters[11], i, response;

	for (i =1; i <= 10; ++i)
		ratingCounters[i] = 0;

	printf("Enter your responses\n");

	for (i = 1; i <= 20; ++i) {
		scanf("%i", &response );
		if (response < 1 || response > 10)
			printf("Invalid response: %i\n", response);
		else
			++ratingCounters[response];
		}

	printf("\n\nRating   Number of Responses\n");
	printf("-------  -----------------------\n");
		
	for (i = 1; i <= 10; ++i)
		printf("%4i%14i\n", i, ratingCounters[i]);

	return 0;
}*/
/*#include <stdio.h>

int main(void)
{
	int Fibonacci[15], i;

	Fibonacci[0] = 0;    // by definition
	Fibonacci[1] = 1;    // by definition

	for (i = 2; i < 15; ++i)
		Fibonacci[i] = Fibonacci[i-2] + Fibonacci[i-1];

	for (i = 0; i < 15; ++i)
		printf("%i\n", Fibonacci[i]);

	return 0;
}*/

/*#include <stdio.h>

int main(void)
{
	int array_values[10] = { 0, 1, 4, 9, 16 };

	int i;

	for (i = 5; i < 10; ++i)
		array_values[i] = i * i;

	for (i = 0; i < 10; ++i)
		printf("array_values[%i] = %i\n", i, array_values[i]);

	return 0;
}*/


/*#include <stdio.h>
int main(){
    char name[] = {'P','r','a','n','a','l','i'};
    
    for(int i=0; i<8; i++){
        printf("%c ",name[i]);
        }
    }*/
    
    
//Fibonnaci Series

/*#include <stdio.h>
int main(){
    int a = 0,b = 1,temp,n;
    printf("Enter the number upto to which you want to print the fibbonacci series: ");
    scanf("%d",&n);

	printf("%d\n",a);
    printf("%d\n",b);
    
    temp = a +b;
    
    for(int i=3; i<=n; ++i){
        printf("%d\n",temp);
        a = b;
        b = temp;
        temp = a + b;
        }
        
        return 0;
}*/
//nclude <stdio.h>
/*
int main(void) 
{
	int count = 10, x;
	//int *int_pointer;      /* declare a variable of type pointer to int "*" */
/*
	int_pointer = &count;  /* create a  pointer with the address operator "&" */
	/*= *int_pointer;      /* assign the value of the pointer to another
							  using the inderection operator "*" variable */

	/*intf("count = %i, x = %i\n", count, x);

	return 0;
}*/
/*#include <stdio.h>
struct entry {
	int          value;
	struct entry *next;
};


struct entry *findEntry(struct entry *listPtr, int match)
{
	while (listPtr != (struct entry *) 0)
		if (listPtr->value == match)
			return (listPtr);
		else
			listPtr = listPtr->next;
	
	return (struct entry *) 0;
}

int main(void) 
{
	struct entry *findEntry(struct entry *listPtr, int match);
	struct entry n1, n2, n3;
	struct entry *listPtr, *listStart = &n1;

	int search;
	
	n1.value = 100;
	n1.next = &n2;

	n2.value = 200;
	n2.next = &n3;

	n3.value = 300;
	n3.next = 0;

	printf("Enter value to locate: ");
	scanf("%i", &search);

	listPtr = findEntry(listStart, search);

	if (listPtr != (struct entry *) 0)
		printf("Fount %i.\n", listPtr->value);
	else
		printf("Not fount.\n");

	return 0;
}*/

/*#include <stdio.h>

int arraySum(int array[], const int n)
{
	int sum = 0, *ptr;
	int * const arrayEnd = array + n;

	for (ptr = array; ptr < arrayEnd; ++ptr)
		sum += *ptr;
	
	return sum;
}

int main(void) 
{
	int arrySum(int array[], const int n);
	int values[10] = { 3, 7, -9, 3, 6, -1, 7, 9, 1, -5 };

	printf("The sum is %i\n", arraySum(values, 10));

	return 0;
}*/


/*#include <stdio.h>

int arraySum(int array[], const int n)
{
	int sum = 0, *ptr;
	int * const arrayEnd = array + n;

	for (ptr = array; ptr < arrayEnd; ++ptr)
		sum += *ptr;
	
	return sum;
}

int main(void) 
{
	//int arrySum(int array[], const int n);
	int values[10] = { 3, 7, -9, 3, 6, -1, 7, 9, 1, -5 };

	printf("The sum is %i\n", arraySum(values, 10));

	return 0;
}*/

        
/*#include <stdio.h>
int mysum(int arr[],int n){
    int sum = 0;
    for(int i=0; i<n; i++)
        sum = sum + arr[i];
        return sum;
    }
int main(){
    int arr[10] = {23,89,-50,64,-1,8,-2,3,8};
    int ans = mysum(arr,10);
    printf("The sum is %i\n",ans);
    return 0;
    }*/
//#include <stdio.h>
/*
Add `int max_of_four(int a, int b, int c, int d)` here.
*/
int max_of_four(int a, int b, int c, int d);

int main() 
{
    int a, b, c, d;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    int ans = max_of_four(a, b, c, d);
    printf("%d", ans);
    
    return 0;
}

int max_of_four(int a, int b, int c, int d)
{
    int max = a;
    if (b > max) {
        max = b;
    }
    if (c > max) {
        max = c;
    }
    if (d > max) {
        max = d;
    }
    return max;
}
/*
#include <stdio.h>

void copyString(char *to, char *from)
{
	for ( ; *from != '\0'; ++from, ++to)
		*to = *from;

	*to = '\0';
}	

int main(void) 
{
	void copyString(char *to, char *from);
	char string1[] = "A string to be copied.";
	char string2[50];

	copyString(string2, string1);
	printf("%s\n", string2);

	copyString(string2, "So is this.");
	printf("%s\n", string2);

	return 0;
}*/

/*#include <stdio.h>
int max_of_four(int a, int b, int c, int d) {
    int max = a;
    if (b > max) {
        max = b;
    }
    if (c > max) {
        max = c;
    }
    if (d > max) {
        max = d;
    }
    return max;
}


int main() {
    int a, b, c, d;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    int ans = max_of_four(a, b, c, d);
    printf("%d", ans);
    
    return 0;
}*/