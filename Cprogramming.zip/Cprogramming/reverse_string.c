#include <stdio.h>
#include <string.h>
int main(){
    char str[30];
    int temp,i,j,size;
    
    printf("Enter the string: ");
    scanf("%s",str);
     
    size = strlen(str);
    
    for(i=0; i<size-1; i++){
        for(j=i+1; j<size; j++){
            temp = str[i];
            str[i] = str[j];
            str[j] = temp;
            }
        }
    printf("Reverse of string %s\n",str);
    return 0;
    }