#include <stdio.h>
int main()
{
    struct tag{
        int i;
        char c;
    };
    struct tag var={2,'a'};
    func(var);
}
func(struct{int i; char c;}v)
{
    printf("%d %c",v.i,v.c);
    
}