#include <stdio.h>

int main(){
    char name[30];
    printf("Enter the string: ");
    scanf("%s",name);
    printf("%s ",name);
    return 0;
    
    }