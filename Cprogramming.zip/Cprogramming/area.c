#include <stdio.h>
#define PI 3.14
int main()
{
    float ra, area ;
    ra = 3.3;
    area = PI * (ra * ra);
    printf("Area of circle = %f",area);
    return 0;
   }