#include <stdio.h>
int main(){
    int a=5, b=6;
    printf("%d\t",a++);
    //printf("%d\t",++a);
    printf("%d %d\t",a,b);
    printf("%d\t",--b);
    printf("%d\t",b--);
    printf("%d %d\t",a,b);
    
    
    return 0;
    }