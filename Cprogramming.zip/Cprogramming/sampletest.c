#include <stdio.h>
int main(){
    int a=-3;
    a = -a-a+!a;
    printf("%d",a);
    return 0;
    }