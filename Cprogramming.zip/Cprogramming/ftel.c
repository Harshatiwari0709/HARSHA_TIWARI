#include <stdio.h>
#include <stdlib.h>
struct record {
    char name [20];
    int roll;
    float marks;
    }student;
    
    int main(){
        FILE *fp;
        fp = fopen("C:/Cworkshop/Cworkshop/append.txt","rb");
        if(fp == NULL){
        printf("Error in opening file\n");
        exit(1);
        }
        printf("position pointer in the beginning -> %ld\n", ftell(fp));
         while(fread(&student,sizeof(student), 1,fp)==1)
        {
            printf("Position pointer -> %ld\n", ftell(fp));
            printf("%s\t",student.name);
            printf("%d\t",student.roll);
            printf("%f\n",student.marks);
            }
            
        printf("Size of file in bytes is %ld\n", ftell(fp));
        fclose(fp);
    }