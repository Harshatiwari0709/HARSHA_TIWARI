#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    FILE *v_fptr;
    
    char v_data[50]="Hello world";
    
    v_fptr = fopen("C:/Cworkshop/Cworkshop/file2.txt","w");
    
    if(v_fptr == NULL){
        printf("file not open");
        }
    else{
        printf("The file is now open. \n");
        
        if(strlen(v_data) > 0) {
            fputs(v_data, v_fptr);
            fputs("\n",v_fptr);
            }
            
            fclose(v_fptr);
            
            printf("Data successfully written in file");
            printf("The file is now closed");
        }
        
        return(0);
    }