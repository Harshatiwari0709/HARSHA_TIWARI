#include <stdio.h>
struct emp{
    char name[20];
    int age;
    int basic_sal;
    };
    
int main(){
    struct emp data[5];
    int i,j,*ts,da,hra;
    for(i=0; i<5; i++){
        printf("Enter the name:");
        scanf("%s",data[i].name);
        printf("Enter the age:");
        scanf("%d",&data[i].age);
        printf("Enter basic salary:");
        scanf("%d",&data[i].basic_sal);
        }
        printf("\n");
        for(i=0; i<5; i++){
            da = 0.01 * data[i].basic_sal;
            hra = 0.05 * data[i].basic_sal;
            ts[i] = data[i].basic_sal + da + hra;
            }
        
        for(j=0; j<5; j++){
            printf("Name: %s Age: %d Total_Salary: %d\n",data[j].name,data[j].age,ts[j]);
            }
    return 0;
    }