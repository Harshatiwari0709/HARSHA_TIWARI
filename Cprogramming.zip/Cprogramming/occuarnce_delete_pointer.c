#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#define MAXSIZE 10
int main(){
    char v_arr[]= "Hello";
    //char v_arrnew[MAXSIZE];
    char *v_pointer = "hello", *v_pointer2;
    int v_count=0,v_size;
   //v_length = strlen(v_arr);
   printf("Enter the size : ");
   scanf("%d",&v_size);
   v_pointer = (char *)malloc(v_size*(sizeof(char)));
   v_pointer2 = v_pointer;
   
   if(v_pointer == NULL){
       printf("Memory not allocated\n");
       exit(0);
       }
else{
    
    for(int i=0; i<v_size; i++){
        for(int j=0; j<v_size; j++){
            if(v_pointer[j] == 'l')
            {
                v_pointer[j] = ' ';
                v_count++;
                }
            }
            
            if(v_count>0){
                v_size = v_size - v_count; 
                }
            printf("length is %d\n",v_size);
            
    for(int j=0; j<=v_size; ++j)
    {
        if((v_pointer[j]==' ')){
            v_pointer2[j] = v_pointer[j+v_count];
            }
        else{
            v_pointer2[j] = v_pointer[j];
            }
        }
        }
        
}
        printf("the replaced string is %s\n",v_pointer);
        printf("the new string is %s\n",v_pointer2);
        
        free()
        
        return 0;
    }