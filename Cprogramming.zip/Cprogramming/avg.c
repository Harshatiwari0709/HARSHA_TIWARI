#include <stdio.h>
int main(){
    int eng,maths,hindi,science,sum;
    float avg;
    printf("Enter the marks of english: ");
    scanf("%d",&eng);
    printf("Enter the marks of Maths: ");
    scanf("%d",&maths);
    printf("Enter the marks of hindi: ");
    scanf("%d",&hindi);
    printf("Enter the marks of science: ");
    scanf("%d",&science);
    //printf("Enter the marks of english: ");
    //scanf("%d",&eng);
    
    sum = (eng+maths+hindi+science);
    
    avg=sum/4;
    
    printf("The average of subjects is = %f",avg);
    }