#include <stdio.h>
int main(){
    int v_fnum=10;
    int v_snum=11;
    
    /*if(v_fnum < v_snum){
        printf("The number is smaller\n");
        if(v_fnum % 2 == 0){
            printf("The number is even");
            }
        }*/
         
         if((v_fnum < v_snum) || (v_fnum % 2 == 0)){
             printf("The number is smaller\n");
             printf("The number is even");
             }
    return 0;
    }