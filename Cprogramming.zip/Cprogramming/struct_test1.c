#include <stdio.h>
struct flights{
    char name[10];
    int time;
    };
    
int main(){
    int i,j,;
    struct flights data[5];
    for(i=0; i<5; i++){
        printf("Enter the name of flights %d: ",i+1);
        scanf("%s",data[i].name);
        printf("Enter the arrival time: ");
        scanf("%d",&data[i].time);
        }
        

        for(j=0; j<5; j++){
           printf("The %s timimg is %d\n",data[j].name,data[j].time);
                }
            }
    