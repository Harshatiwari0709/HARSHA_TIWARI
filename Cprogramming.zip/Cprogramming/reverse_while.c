#include <stdio.h>
int main(){
    int num,temp,rem=0,rev=0;
    printf("Enter a number: ");
    scanf("%d",&num);
    temp = num;
    /*while(temp!=0){
        rev = temp%10;
        rem = rem*10 + rev;
        temp = temp / 10;
        }
        printf("%d",rem);*/
        
        do{
            rev = temp%10;
            rem = rem*10 + rev;
            temp = temp/10;
            }while(temp!=0);
            printf("%d",rem);
        return 0;
        
    }