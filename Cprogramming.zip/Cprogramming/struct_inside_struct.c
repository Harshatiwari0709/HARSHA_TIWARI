#include <stdio.h>
struct parent{
    char v_pname[10];
    int v_psalary;
    };
    
struct child
{
    char v_cname[10];
    struct parent v_parent;
    };

int main()
{
    struct child v_mainchild = {"John","King",20000};

printf("The child, Parent name and salary is %s %s %d",v_mainchild.v_cname,v_mainchild.v_parent.v_pname,v_mainchild.v_parent.v_psalary);

return 0;   
}
    
