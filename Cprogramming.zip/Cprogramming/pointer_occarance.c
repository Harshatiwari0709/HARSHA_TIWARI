#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#define MAXSIZE 10
int main(){
    char v_arr[]= "Hello";
    char v_arrnew[MAXSIZE];
    int v_length,v_count=0;
    v_length = strlen(v_arr);
    
    for(int i=0; i<v_length; i++){
        for(int j=0; j<v_length; j++){
            if(v_arr[j] == 'l')
            {
                v_arr[j] = ' ';
                v_count++;
                }
            }
            
            if(v_count>0){
                v_length = v_length - v_count; 
                }
            printf("length is %d\n",v_length);
            
    for(int j=0; j<=v_length; ++j)
    {
        if((v_arr[j]==' ')){
            v_arrnew[j] = v_arr[j+v_count];
            }
        else{
            v_arrnew[j] = v_arr[j];
            }
        }
        }
        printf("the replaced string is %s\n",v_arr);
        printf("the new string is %s\n",v_arrnew);
        
        
        return 0;
    }