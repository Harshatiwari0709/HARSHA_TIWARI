#include <stdio.h>
#include <string.h>
//#include <ctype.h>

int main()

{
    char v_str[]="Hello";
    char v_strnew[]="HELLO";
     int v_length;
     v_length=strlen(v_str);
     printf("The length is %d \n",v_length);
     
     if (strcmp(v_str,v_strnew)==0)
     {
         printf("Strings are same\n");
         
     }
     else{
         printf("Strings are different\n");
     }
     printf("concatenated strings are %s \n",strcat(v_str,v_strnew));
     printf("Existence of string1 in String 2 %s \n",strstr(v_str,v_strnew));
     
     printf("Before copy %s \n", v_str);
     strcpy(v_str,v_strnew);
     printf("After copy %s \n",v_str);
     
     return 0;
}