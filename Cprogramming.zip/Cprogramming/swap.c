#include <stdio.h>
#include <stdbool.h>
int main(){
    int v_fnum,v_snum,v_swap_temp;
    v_fnum = NULL;
    bool var = true;
    printf("var = %d",var);
    v_snum = 20;
    int sum = v_fnum + v_snum;
    printf("sum = %i", sum);
    v_swap_temp = v_fnum;
    v_fnum = v_snum;
    v_snum = v_swap_temp;
    printf("v_fnum = %d, v_snum = %d",v_fnum,v_snum);
    return 0;
    }