#include <stdio.h>
int main()
{
    int a,b,sum,diff,prod;
    a=6;
    b=4;
    func(a,b,&sum,&diff,&prod);
    printf("Sum=%d, difference = %d, product =%d\n",sum,diff,prod);
    return 0;
}
func (int x, int y, int ps[], int pd[], int pp[])
{
    ps[0]=x+y;
    pd[0]=x-y;
    pp[0]=x*y;
}