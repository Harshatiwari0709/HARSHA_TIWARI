#include <stdio.h>
int main(){
    int v_fnum = 10;
    int v_snum = 11;
    int v_tnum = 12;
    
    if(v_fnum > v_snum){
        if(v_fnum > v_tnum){
            printf("%d is larger",v_fnum);
            }
        }
        
    if(v_snum > v_fnum){
        if(v_snum > v_tnum){
            printf("%d is larger",v_snum);
            }
        }
        
    if(v_tnum > v_fnum){
        if(v_tnum > v_snum){
            printf("%d is larger",v_tnum);
            }
        }
    }