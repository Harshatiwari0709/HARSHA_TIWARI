#include <stdio.h>
int main(){
    int num,temp,count=0,rem;
    printf("Enter a number: ");
    scanf("%d",&num);
    temp = num;
    /*while(temp!=0){
        rem = temp%10;
        count = count + rem;
        temp = temp/10;
        }
        printf("%d",count);*/
        
        do{
            rem = temp%10;
            count = count + rem;
            temp = temp/10;
            }while(temp!=0);
            
            printf("%d",count);
        return 0;
    }