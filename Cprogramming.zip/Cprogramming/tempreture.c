#include <stdio.h>
int main(){
    float cel,far;
    printf("Enter the celcius: ");
    scanf("%f",&cel);
    far = (cel*9/5)+32;
    printf("The farehenite value is : %0.2f",far);
    return 0;
    }
    
    //(0°C × 9/5) + 32