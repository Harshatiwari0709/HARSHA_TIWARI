#include <stdio.h>
int main(){
    int arr[5];
    
    }