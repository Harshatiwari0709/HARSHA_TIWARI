#include <stdio.h>
#include <stdlib.h>
int main()
{
    FILE *v_fptr;
    char v_read[50];
    v_fptr=fopen("C:/Cworkshop/Cworkshop/file.txt","r");
if(v_fptr==NULL){
    printf("file is not opened");
    exit(0);
}
while (fgets(v_read, 50, v_fptr)
!=  NULL){
    printf("%s",v_read);
}
fclose(v_fptr);
printf("Data successfully read");
return 0;
}