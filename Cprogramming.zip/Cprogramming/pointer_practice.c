/*#include <stdio.h>
int main(){
    int count=50;
    int *ptr,x;
    
    ptr = &count;
    
    x = *ptr;
    
    printf("value of count: %d, value of x: %d",count, x);
    return 0;
    }*/
    
#include <stdio.h>
int main(){
    char str = 'P';
    char *ptr = &str;
    
    printf("First %c: \n",*ptr);
    str = '*';
    printf("Second %c: \n",*ptr);
    str = '(';
    printf("Third %c: ",*ptr);
    return 0;
    }