#include <stdio.h>
struct student{
    char name[20];
    int age;
    };
int main(){
    struct student stu1 = {"King",10},stu2={"Jhon",20};
    
    if(stu1==stu2){
        printf("same");
        }
    else{
        printf("different");
        }
    }