#include <stdio.h>
enum mytest{Linux, Mac=11, Windows};
int main()
{
    enum mytest myvar;
    myvar=Mac;
    printf("Os is %d",myvar);
    return 0;
}