#include <stdio.h>
int main(){
    int a = 10;
    a = a++*a--;
    printf("%d",a);
    }