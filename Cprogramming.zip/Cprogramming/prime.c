#include <stdio.h>
int main(){
    int v_num;
    printf("Enter the number: ");
    scanf("%d",&v_num);
    
    if(v_num%2!= 0)
    {
        if ((v_num%v_num==0)&&(v_num%1==0))
        {
            if((v_num%3!=0))
                {  
                    if (v_num%5!=0) {
                      if  (v_num%7!=0) {
                          printf("%d a Prime Number",v_num); 
                      }
                    }
                }
              else 
              {
                  printf ("not prime number");
              }
            }
        }
        
        else{
            printf ("not prime number");
            }
    
          return 0;    
    }
    
          
    
   