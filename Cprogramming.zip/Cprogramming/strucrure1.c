#include <stdio.h>
    
    struct c_vehicle
    {
        char v_color[10];
        char v_model[10];
        };
        
    int main()
    {
        typedef struct c_vehicle v_struct;
        v_struct var1 = {"Hello","World"};
        printf("record variable are %s %s",var1.v_color,var1.v_model);
        
        return 0;
        }