#include <stdio.h>

void update(int *a,int *b) {
  int add;
  //int *c=*a;
  int sub;
  add=*a+*b;
  sub=*b-*a;
  *a=add;
  *b=sub;
  }

int main() {
    int a=4, b=5;
    update(&a, &b);
    printf("%d\n%d",a, b);

    return 0;
}