#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXLEN 1000
#define NAME_MAXLEN 64
#define isInBounds(N) (N) > 0 && (N) < MAXLEN

int main(){
    char filename[NAME_MAXLEN], line[MAXLEN], *line_begin;
    int m,n,length;
    FILE *inFile;
    
    printf("Enter name of file to be used: ");
    scanf("%63s",filename);
    
    if(!(inFile = fopen(filename,"r"))){
        fprintf(stderr,"Can't open %s for reading.\n",filename);
        exit(EXIT_FAILURE);
        }
        
    printf("For every line, printf columns m through n: (1-999)\n");
    printf("m: ");
    if(!scanf("%i",&m)) {
        fclose(inFile);
        exit(EXIT_FAILURE);
    
        }
        printf("n:");
        if(!scanf("%i", &n)) {
            fclose(inFile);
            exit(EXIT_FAILURE);
        }
        line_begin = &line[m-1];
        length = n-m+1;
        
        if(!(isInBounds(length) && isInBounds(m) && isInBounds(n))){
            fprintf(stderr,"ERROR: invalid range\n");
            fclose(inFile);
            exit(EXIT_FAILURE);
            
        }  
        printf("\n");
        while(fgets(line,MAXLEN,inFile))
            fprintf(stdout,"%.*s\n",length, line_begin);
            fprintf(stdout,"%10s","hello");
            fclose(inFile);
            exit(EXIT_SUCCESS);
  }