#include <stdio.h>
#include <stdlib.h>
struct node{
    int info;
    struct node *next;
    
};
struct node *createList(struct node *start);
void displayList(struct node *start);
struct node *insertInBeginning(struct node *start,int data);

int main()
{
    struct node *start=NULL;
    int choice, data, x, k;
    start = createList(start);
    displayList(start);
    printf("Enter a element to insert in before the list or in an empty list:");
    scanf("%d",&data);
    start=insertNodeAtEnd(data);
    displayList(start);
}
struct node *createList(struct node *start)
{
    int i,n,data;
    printf("Enter the no of nodes:");
    scanf("%d",&n);
    if(n==0)
        return start;
        
    printf("Enter the last element to be inserted:");
    scanf("%d",&data);
    last=insertNodeAtEnd(data);
    for(i=2;i<=n;i++)
    {
        printf("Enter the next element to be inserted:");
        scanf("%d",&data);
        insertAtEnd( data);
    }
    return start;
};
/*
struct node *insertInBeginning(struct node *start, int data)
{
    struct node *temp;
    temp=(struct node *)malloc(sizeof(struct node));
    
    temp->info=data;
    temp->link=start;
    start=temp;
    return start;
};*/
void insertAtEnd(struct node *start, int data)
{
    struct node *temp, *p;
    temp=(struct node *)malloc(sizeof(struct node));
    temp->info=data;
    p=start;
    while(p->link!=NULL)
    {
      p=p->link;
    }
    p->link=temp;
    temp->link=NULL;
}

void insertNodeAtEnd(int data)
{
    struct node *newNode, *temp;
    newnode =(struct node *)malloc(sizeof(struct node));
    
    if(newNode == NULL)
    {
      printf("Unable to allocate memory:");
    }
    else
    {
        newNode->data = data;
        newNode->next = NULL;
    
    temp = head;
    while(temp->next != NULL)
    temp = temp->next;
    
    temp->next =newNode;
    printf("Done Insertion\n");
}
}

void displayList(struct node *start)
{
    struct node *temp;
    if(head==NULL)
    {
        printf("List is empty\n");
        return;
    }
        printf("List is:");
        p=start;
        while(p!=NULL)
        {
            printf("%d ",p->info);
            p=p->link;
            
        }
        printf("\n");
}
