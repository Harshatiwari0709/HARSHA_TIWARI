#include <stdio.h>
int main(){
    int num,temp,sum=0,rem;
    printf("Enter the number: ");
    scanf("%d",&num);
    temp=num;
    while(temp!=0){
        rem = temp%10;
        sum = sum + (rem*rem);
        temp = temp/10;
        }
        printf("%d",sum);
    return 0;
    }