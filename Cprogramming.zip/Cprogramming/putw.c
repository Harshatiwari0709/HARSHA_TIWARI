#include <stdio.h>
main()
{
    FILE * fptr;
    int value;
    fptr=fopen("C:/Cworkshop/Cworkshop/file_wb.txt","rb");
    //for(value=1;value<=30;value++)
        //putc(value,fptr);
        
    while((value=getw(fptr))!=EOF)
       printf("%d\t",value);
        fclose(fptr);
}