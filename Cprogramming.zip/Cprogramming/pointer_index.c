#include <stdio.h>
int main()
{
    int v_data[5];
    printf("Enter elements:");
    for (int i=0; i<5; ++i){
    scanf("%d", v_data +i);
    
    printf("You entered: \n");
    for(int i=0; i<5 ; ++i)
        printf("%d\n", *(v_data +i));
}

        return 0;
}