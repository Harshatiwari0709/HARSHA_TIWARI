#include <stdio.h>
#include <math.h>
int main(){
    int side1,side2,hypo;
    printf("Enter the value of side1:");
    scanf("%d",&side1);
    printf("Enter the value of side2:");
    scanf("%d",&side2);
    hypo = sqrt((side1*side1)+(side2*side2));
    printf("The hypotenuse is %d: ",hypo);
    return 0;
    }