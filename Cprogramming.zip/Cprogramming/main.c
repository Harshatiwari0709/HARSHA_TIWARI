#include<stdio.h>
void main() {
    int number;
    printf("Enter a integer");
    scanf("%d",&number);
    printf("YOU ENTERED: %d ",number);
    return 0;
    }