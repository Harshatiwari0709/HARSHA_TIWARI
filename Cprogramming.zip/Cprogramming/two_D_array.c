#include <stdio.h>
int main(){
    int x [2][3]=
                    {
                        {0,1,3},
                        {2,3,8}
                    };
                    
                
                
    for(int i=0; i<2; i++)
    {
       for(int j=0; j<3; j++) {
           printf("element at x[%i][%i]",i,j);
           printf("%d\n",x[i][j]);
       }
    }
    return 0;
}