#include <stdio.h>
#include <stdlib.h>

typedef struct node{
    int data;
    struct node *link;
    };
    
int main(){
    struct node *head = NULL, *current, *current2;
    
    head = (struct node*)malloc(sizeof(struct node));
    
    head->data = 45;
    head->link = NULL;
    
    current = (struct node*)malloc(sizeof(struct node));
    
    current->data = 66;
    current->link = NULL;
    head->link = current;
    
    current2 = (struct node*)malloc(sizeof(struct node));
    
    current2->data = 86;
    current2->link = NULL;
    current2->link = current;
    
    printf("%d ",head->data);
    printf("%d ",current->data); 
    printf("%d ",current2->data);
    
    
    return 0;
    }