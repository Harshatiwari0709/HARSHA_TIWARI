#include <stdio.h>
int main(){
    double num;
    printf("Enter the number: ");
    scanf("%ld",&num);
    printf("The octal value of is %o\n",num);
    printf("The hexadecimal value of is %x",num);
    }