#include <stdio.h>

typedef struct student{
    char name[50];
    int roll;
    float marks;
    }newstd;
    
void display(newstd *student_obj)
{
    printf("Name: %s\n", student_obj->name);
    printf("Roll: %d\n", student_obj->roll);
    printf("Marks: %f\n", student_obj->marks);
    }
    
int main(){
    newstd  st1 = {"Pranali", 19, 8.2};
    display(&st1);
    return 0;
    }