#include <stdio.h>
#include <string.h>
#define MAXSIZE 10
int main(){
    char *str;
    char str1 =str*;
    int i,j;
    
        
        
        return 0;
    }