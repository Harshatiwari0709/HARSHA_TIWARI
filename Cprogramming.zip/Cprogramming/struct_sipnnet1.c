#include <stdio.h>
int main(){
    struct rec{
        char *name;
        int age;
        }*ptr;
        
    char name[10] = "Hello";
    ptr->name = name;
    ptr->age = 93;
    printf("%s\n",ptr->name);
    printf("%d\n",ptr->age);
    return 0;
    }