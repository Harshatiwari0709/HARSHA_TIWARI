#include <stdio.h>
#include <stdlib.h>
struct node{
    int info;
    struct node *link;
    
};
struct node *createList(struct node *start);
void displayList(struct node *start);
struct node *insertInBeginning(struct node *start,int data);

int main()
{
    struct node *start=NULL;
    int choice, data, x, k;
    start = createList(start);
    displayList(start);
    printf("Enter a element to insert in before the list or in an empty list:");
    scanf("%d",&data);
    start=insertInBeginning(start, data);
    struct node *insert
    displayList(start);
}
struct node *createList(struct node *start)
{
    int i,n,data;
    printf("Enter the no of nodes:");
    scanf("%d",&n);
    if(n==0)
        return start;
        
    printf("Enter the first element to be inserted:");
    scanf("%d",&data);
    start=insertInBeginning(start, data);
    for(i=2;i<=n;i++)
    {
        printf("Enter the next element to be inserted:");
        scanf("%d",&data);
        insertAtEnd(start, data);
    }
    return start;
};
struct node *insertInBeginning(struct node *start, int data)
{
    struct node *temp;
    temp=(struct node *)malloc(sizeof(struct node));
    
    temp->info=data;
    temp->link=start;
    start=temp;
    return start;
};
void insertAtEnd(struct node *start, int data)
{
    struct node *temp, *p;
    temp=(struct node *)malloc(sizeof(struct node));
    temp->info=data;
    p=start;
    while(p->link!=NULL)
    {
      p=p->link;
    }
    p->link=temp;
    temp->link=NULL;
}
struct node *insertAtPostion(struct node *start, int data, int k)
{
    struct node *temp,*p;
    int i;
    if(k==1)
    {
        temp=(struct node*)malloc(sizeof(struct node));
        temp->info=data;
        temp->link=start;
        start=temp;
        
        return start;
    }
    p=start;
    for(i=1; i<k-1 && p!=NULL; i++)
        p=p->link;
        if(p==NULL)
            printf("not able to insert\n",i);
            else
            {
                temp=(struct node *)malloc(sizeof(struct node));
                temp->info=data;
                temp->link=p->link;
                p->link=temp;
            }
            return start;
}

void displayList(struct node *start)
{
    struct node *p;
    if(start==NULL)
    {
        printf("List is empty\n");
        return;
    }
        printf("List is:");
        p=start;
        while(p!=NULL)
        {
            printf("%d ",p->info);
            p=p->link;
            
        }
        printf("\n");
}
