#include <stdio.h>

//call by value
void swap(int *v_num1, int *v_num2){
    int v_temp ;
    v_temp = *v_num1;
    *v_num1 = *v_num2;
    *v_num2 = v_temp;
    }
    
    
    int main(){
        int v_var1 =10, v_var2=20;
        printf("Before swap %d %d\n",v_var1,v_var2);
        swap(&v_var1,&v_var2);
        printf("After swap %d %d\n",v_var1,v_var2);
        
        return 0;
        }