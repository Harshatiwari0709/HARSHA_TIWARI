#include <stdio.h>
#define MAX_SIZE 100
int main(){
    int v_arr[MAX_SIZE];
    int v_num,v_even,v_odd,v_size;
    
    //input the size of array;
    printf("Enter the size");
    scanf("%d",&v_size);
    
    //input array elements
    printf("Enter elements in the array: ");
    for(v_num=0; v_num<=v_size; v_num++){
        scanf("%d",&v_arr[v_num]);
        }
        
        //Initialization 
        
    v_even=0;
    v_odd=0;
        for(v_num=0; v_num<=v_size;v_num++)
        {
            if(v_arr[v_num]%2==0){
                v_even++;
                }
            else{
                v_odd++;
                }
            }
            
            //print odd and even
            printf("even count is %d", v_even);
            printf("odd count is %d", v_odd);
    return 0;
    }