#include <stdio.h>
//function decaration
int addnum(int a,int b){
    return a+b;
    }
int main() {
    //int v_fnum = 10;
    //int v_snum = 20;
    int v_sum = 0;
    
    //v_sum = addnum(v_fnum,v_snum);
    
    //case1: Call function without value
    //v_sum = addnum();
    
    //case2: call function with one parameter
   // v_sum = addnum(v_fnum);
   
   
   //case3: Do not capture the value to declare variable
   v_sum = addnum(v_fnum,v_snum);
    printf("the sum is %d",v_sum);
    }                                                               