#include <stdio.h>
int main(){
    int x,y,z;
    printf("enter value x: ");
    scanf("%d",&x);
    printf("enter value y: ");
    scanf("%d",&y);
    printf("enter value x: ");
    scanf("%d",&z);
    if(x==y && y==z ){
        printf("x is equal to z \n value of z is : %d",z);
        }
    else{
        printf("x is not equal to z");
        }
        return 0;
    }