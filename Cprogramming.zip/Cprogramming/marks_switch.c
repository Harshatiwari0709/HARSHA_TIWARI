#include <stdio.h>
int main(){
    int marks;
    printf("Enter the makrs: ");
    scanf("%d",&marks);
    if(marks<100 && marks>90){
        printf("grade 'O'");
        }
    else if(marks<90 && marks>85){
        printf("grade 'A'");
        }
    else if(marks<85 && marks> 80){
        printf("grade 'B'");
        }
    else if(marks<85 && marks>75){
        printf("grade 'C'");
        }
    else{
        printf("grade 'D'");
        }
        
    
        
        return 0;
    }
    