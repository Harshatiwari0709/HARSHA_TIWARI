#include <stdio.h>
#include <string.h>

int main()
{
    char str1[30];
    //char key = 'a';
    char key,replace;
    int n,i;
    
    printf("Enter the elements : ");
    scanf("%s",str1);
    printf("Enter the charater to be search: ");
    scanf(" %c",&key);
   printf("Enter the charater to replace:");
   scanf(" %c",&replace);
    n = strlen(str1);
    

    //printf("%d\n",n);
    
    for(i=0; i<n; i++){
        if(str1[i]==key){
            //printf("%c",str1[i]);
            str1[i] = replace;
        }
    }
        
       printf("new string is: %s",str1);
   
    return 0;
}