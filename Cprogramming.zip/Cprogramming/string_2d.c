#include <stdio.h>
int main(){
    
    char x[2][5]={
                    {'p','r','a','n','a','\0'},
                    {'m','a','r','a','s','\0'}
                    };
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<5;j++)
        {
            printf("elements at x[%i][%i]",i,j);
            printf("%c\n",x[i][j]);
        }
    }
    return 0;
    }