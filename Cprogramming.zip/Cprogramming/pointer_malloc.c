#include <stdio.h>
#include <stdlib.h>
int main(){
    int * v_pointer;
    int v_num,v_loop;
    
    printf("enter the number of elements: ");
    scanf("%d",&v_num);
    
    v_pointer = (int *)malloc(v_num*(sizeof(int)));
    
    if(v_pointer == NULL){
        printf("Memory not allocated \n");
        exit(0);
        }
    else{
        printf("memory successfully allocated"); 
        for(v_loop=0; v_loop<v_num; v_loop++){
            v_pointer[v_loop] = v_loop+1;
            }
        printf("The elements of the array are: ");
        for(v_loop=0; v_loop<v_num; ++v_loop){
            printf("%d, ",v_pointer[v_loop]);
            }
            free(v_pointer);
        }
        
        return 0;
    }