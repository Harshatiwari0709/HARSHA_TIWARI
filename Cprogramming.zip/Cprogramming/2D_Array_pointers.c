#include <stdio.h>
#include <stdlib.h>

void main()
{
    int i,j,rows,k;
    int (*a)[4][4];
    printf("Enter number of rows");
    scanf("%d",&rows);
    a=(int(*)[4][4])malloc(rows*16*sizeof(int));
    for(i=0;i<rows;i++)
    for(j=0;j<4;j++)
    {
        for(int k=0; k<4; k++){
        printf("Enter a[%d] [%d]",i,j);
        scanf("%d",&a[i][j][k]);
        }
        }
    
    printf("The matrix is:\n");
    for(i=0;i<rows;i++)
    {
        for(j=0;j<4;j++){
            for(int k=0; k<4; k++)
            printf("%5d", a[i][j][k]);
            printf("\n");
        }
    }
    free(a);
}