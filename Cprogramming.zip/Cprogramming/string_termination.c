#include <stdio.h>
int main(){
    printf("Testing null character \0 and display it");
    return 0;
    }