#include <stdio.h>
int main(){
    int v_num,arr[50],i;
    printf("Enter the decimal num : ");
    scanf("%d",&v_num);
    for( i=0; v_num>0; i++){
        arr[i] = v_num%2;
        v_num = v_num/2;
        }
        
        //printf()
        for(i =i-1; i>=0; i--){
            printf("%d",arr[i]);
            }
            
            return 0;
    }