#include <stdio.h>
int main(){
    int year,rem;
    printf("Enter a year: ");
    scanf("%d",&year);
    rem = year%100;
    printf("%d",rem);
    
    if(rem<=50){
        printf(" Pervious year");
        }
    else{
        printf(" Current year");
        }
    
    return 0;
    }