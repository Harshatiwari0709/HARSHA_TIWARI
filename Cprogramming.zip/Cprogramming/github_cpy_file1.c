#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

#define NAME_MAXLEN 64

int main(){
    char inName[NAME_MAXLEN], outName[NAME_MAXLEN];
    int c;
    FILE *in, *out;
    
    printf("Enter name of the file to be copied:");
    scanf("%64s",inName);
    
     printf("Enter name of the file to be copied:");
    scanf("%64s",outName);
    
    if(!(in = fopen(inName,"r"))){
        fprintf(stderr,"Can't open %s for reading,\n",inName);
        exit(EXIT_FAILURE);
    }
     if(!(out = fopen(outName,"w"))){
        fprintf(stderr,"Can't open %s for writing,\n",outName);
        exit(EXIT_FAILURE);
    }

while ((c = getc(in)) !=EOF)
    putc(tolower(c),out);
    
fclose(in);
fclose(out);
exit(EXIT_SUCCESS);
}