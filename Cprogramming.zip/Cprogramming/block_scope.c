#include <stdio.h>
//local variable

int var1=101, var2=102;

void swap(int v_num1,int v_num2){
    int v_temp;
    v_temp = v_num1;
    v_num1 = v_num2;
    v_num2 = v_temp;
    //printf("After swap %d %d\n",v_num1,v_num2);
    }
     
    

int main(){
    //int var1=101, var2=102;
    {
        int var1=5,var2=6;
        printf("Before swaping %d %d\n",var1,var2);
        swap(var1,var2);
        }
        
        printf("After swaping %d %d\n",var1,var2);
        //swap(var1,var2);
        return 0;
    }