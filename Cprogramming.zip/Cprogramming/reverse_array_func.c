#include <stdio.h>
void read(int arr[],int size){
    printf("Enter the element in array:");
    for(int i=0;i<=size;i++){
        scanf("%d",&arr[i]);
        }
    }
int main(){
    int size,i=0,temp;
    printf("Enter the size of array: ");
    scanf("%d",&size);
    int arr[size];
    read(arr,size);
    int j=size-1;
    while(i>j){
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        }
        
    printf("Display the reverse element in array: ");
    for(int i=size;i>0;i--){
        printf("%d ",arr[i]);
        }
    
    }