#include <stdio.h>
#include <stdlib.h>

int main(){
    struct student{
        char name[50];
        int roll_no;
        int marks;
        };
        
    struct student data[10];
    int n;
    printf("Enter the records how much you want to enter: ");
    scanf("%d",&n);
    for(int i=0; i<n; i++){
        printf("Enter Your Name: ");
        scanf("%s",data[i].name);
        printf("Enter your roll no.: ");
        scanf("%d",&data[i].roll_no);
        printf("Enter your Marks: ");
        scanf("%d",&data[i].marks);
        printf("\n");
    }
    
    for(int i=0; i<n; i++){
        
    printf("Your Name is:  %s\n",data[i].name);
    printf("your Roll_no is: %d\n",data[i].roll_no);
    printf("Your Marks is: %d",data[i].marks);
    printf("\n");
    }
    
    return 0;
    
    }