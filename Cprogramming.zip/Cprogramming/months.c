#include <stdio.h>
int main(){
    int var = 1411211998,n1,n2;
    n1 = var%10000000;
    //printf("%d\n",n1);
    n2 = n1/100000;
    printf("Month is : %d",n2);
    return 0;
    }