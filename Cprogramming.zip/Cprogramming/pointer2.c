#include <stdio.h>
int main()

{
    int v_array[5];
    int *v_pointer = &v_array;
    int *v_pointerele=&v_array[0];
    if(v_pointer == v_pointerele){
        printf("elements are same");
    }
    else{
        printf("elements are different");
    }
    return 0;
}