#include <stdio.h>
int main(){
    int n1,prod1,prod2;
    printf("Enter number1: ");
    scanf("%d",&n1);
    printf("Enter number2: ");
    scanf("%d",&n2);
    //table of number1
    /*for(int i=0; i<=10; i++){
        prod = n1 * i;
        printf("%d X %d = %d\n",n1,i,prod);
        }*/
        
        for(int i=0; i<=10; i++){
            prod1=n1*i;
            prod2=n2*i;
            if(prod1==prod2){
                
                }
            }
    return 0;
    }