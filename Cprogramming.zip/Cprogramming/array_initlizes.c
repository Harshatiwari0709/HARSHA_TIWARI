#include <stdio.h>
int main(){
    //array initialization with size declaration
    int v_arr[5] = {10,20,30,45,50};
    
    //array initilization with no size declaration
    int v_arrnew[] = {100,200,300,400,500};
    
    int v_arrloop[5];
    
    //array initlization in loop
    for(int i=0; i<5;i++){
        v_arrloop[i] = 2*i;
        }
        
    printf("First array element %d",v_arr[2]);
    printf("second array element %d",v_arrnew[3]);
    printf("Third array element %d",v_arrloop[1]);
    
    return 0;
    }