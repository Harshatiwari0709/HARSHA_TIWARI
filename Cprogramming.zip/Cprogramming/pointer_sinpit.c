#include <stdio.h>
int main(){
    /*int arr[90]={25,30,35,40,45,50,55,60,65,70,75,80,85,90},*p=arr;
    for(p=&arr[0]; p<arr+10; p++)
        printf("%d ",*p);*/
        
        /*int arr[8] = {11,22,33,44,55,66,77,88},x;
        x = (arr+2)[3];//3 is for position
        printf("%d ",x);*/
        
        int arr[8] = {11,22,33,44,55,66,77,88};
        int *p,*q;
        for(int i=0; i<8; i++){
            q = arr[i]/2;
            p = q * 2;
            printf("%d %d ",*(q+i),*p);
            
            }

        
        
        
    return 0;
    }