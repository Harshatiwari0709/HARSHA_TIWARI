#include <stdio.h>
int main(){
    int x [2][3][3]={
                        {{0,1,5},{1,2,8},{2,3,9}},
                        {{2,9,8},{9,8,6},{9,2,1}}
                    };                       
    for(int i=0; i<2; i++)
    {
       for(int j=0; j<3; j++) {
           for(int k=0; k<3; k++){
           printf("element at x[%i][%i][%i]",i,j,k);
           printf("%d\n",x[i][j][k]);
           
           }
       }
    }
    return 0;
}