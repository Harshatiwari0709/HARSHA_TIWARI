#include <stdio.h>
#include <string.h>

struct employee {
    char ename[10];
    int esalary;
    };
    
    int main(){
        struct employee v_emp[5];
        
        for(int i=0; i<5; i++){
            strcpy (v_emp[i].ename,"pranali");
            v_emp[i].esalary = 20000*(i+1);
            }
            
        for(int i=0; i<5; i++){
            printf("the emplyee details are %s %d\n",v_emp[i].ename, v_emp[i].esalary);
            }
            
            return 0;
        }