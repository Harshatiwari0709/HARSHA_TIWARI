#include<stdio.h>
main()
{
    int i;
    fprintf(stdout,"Give value of i\n");
    fscanf(stdin,"%d",&i);
    fprintf(stdout,"Value of i=%d\n",i);
}