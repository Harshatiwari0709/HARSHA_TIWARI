#include <stdio.h>
#include <stdlib.h>

main()
{
    struct record
    {

    char name [20];
    int roll;
    float marks;
    }student;
    
    FILE *fp;
    int choice = 1;
    fp = fopen("C:/Cworkshop/Cworkshop/append.txt","wb");
    if(fp == NULL){
        printf("Error in opening file\n");
        exit(1);
        }
        
        /*printf("\nName\tROLL NO\tMarks\n");
        while(fread(&student,sizeof(student), 1,fp)==1)
        {
            printf("%s\t",student.name);
            printf("%d\t",student.roll);
            printf("%f\n",student.marks);
            }*/
        
        while(choice ==1){
            printf("Enter name: ");
            scanf("%s",student.name);
            printf("Enter roll no. : ");
            scanf("%d",&student.roll);
            printf("Enter marks: ");
            scanf("%f",&student.marks);
            fwrite(&student,sizeof(student),1,fp);
            printf("Want to enter more?(1 for yes/ 0 for no)");
            scanf("%d",&choice);
            }
            fclose(fp);
            }