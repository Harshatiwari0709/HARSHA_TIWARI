#include <stdio.h>
#include <stdlib.h>

typedef struct node{
    int data;
    struct node *link;
    };
    
struct node *createList(int n);
void display(struct node *head);
    
int main(){
    struct node *head = NULL;
    int n = 0;
    printf("How many nodes you want to enter: ");
    scanf("%d",&n);
    head = createList(n);
    display(head);
    return 0;
    }
    
struct node *createList(int n){
    int i;
    struct node *head = NULL, *temp = NULL, *p = NULL;

    for(i=0; i<n; i++){
        temp = (struct node*)malloc(sizeof(struct node));
        printf("Enter the data for node: ",i+1);
        scanf("%d",&(temp->data));
        temp->link = NULL;
        
        if(head == NULL){
            head = temp;
            }
        else{
            p = head;
            while(p->link != NULL)
                p = p->link;
                
            p->link = temp;
            }
        }
        return head;
    }
    
void display(struct node *head){
    struct node *p = head;
    while(p != NULL){
        printf("%d ",p->data);
        p = p->link;
        }
    }