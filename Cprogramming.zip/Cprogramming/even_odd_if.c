#include <stdio.h>
int main(){
    int num1;
    printf("Enter number: ");
    scanf("%d",&num1);
    //printf("Enter number: ");
    //scanf("%d",&num2);
    if(num1<9){
        if(num1==1){
            printf("one");
            }
        else if(num1==2){
            printf("two");
            }
        else if(num1==3){
            printf("three");
            }
        else if(num1==4){
            printf("four");
            }
        else if(num1==5){
            printf("five");
            }
        else if(num1==6){
            printf("six");
            }
        else if(num1==7){
            printf("seven");
            }
        else if(num1==8){
            printf("eight");
            }
    }
    else if(num1>9){
        if(num1%2 == 0){
            printf("even\n");
            }
        else{
            printf("odd\n");
            }
            
            printf("nine");
        
        }
        
    
    
        return 0;
    }