#include <stdio.h>
int main(){
    int a=5,*ptr;
    ptr = &a;
    printf("Input number:");
    scanf("%d",ptr);
    printf("%d %d",a,*ptr);
    return 0;
    }