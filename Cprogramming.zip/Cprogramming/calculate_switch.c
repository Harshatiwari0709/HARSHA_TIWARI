#include <stdio.h>
int main(){
    int num,n1,n2,ans;
    printf("Enter value for Number1: ");
    scanf("%d",&n1);
    printf("Enter value for Number2: ");
    scanf("%d",&n2);
    printf(" 1.Addition\n 2.Asubtraction\n 3.Multiplication\n 4.Division\n");
    printf("Enter a choice: ");
    scanf("%d",&num);
    switch(num){
        case 1:
            ans = n1 + n2;
            printf("The Addition is %d",ans);
            break;
            
        case 2:
            ans = n1 - n2;
            printf("The Subtration is %d",ans);
            break;
            
        case 3:
            ans = n1 * n2;
            printf("The Multilpication is %d",ans);
            break;
         
        case 4:
            ans = n1 / n2;
            printf("The Division is %d",ans);
            break;
            
        default:
            printf("Invalid");
            break;
        
        }
    return 0;}