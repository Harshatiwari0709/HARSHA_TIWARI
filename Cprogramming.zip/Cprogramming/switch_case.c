#include <stdio.h>
int main(){
    
    int v_fvar;
    
    printf("Enter the value to be checked from 1-3: ");
    scanf("%d",&v_fvar);
    if(v_fvar < 1 && v_fvar > 3){
        return 1;
        }
        
        switch(v_fvar) {
            case 1:
            printf("we are in first case");
            break;
            
            case 2:
            printf("we are in second case");
            break;
            
            case 3:
            printf("we are in third case");
            break;
            
            default:
            printf("invalid value");
            break;
            }
    return 0;
    }