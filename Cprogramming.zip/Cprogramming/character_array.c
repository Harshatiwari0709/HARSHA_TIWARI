#include <stdio.h>
int main(){
    int n,i,j;
    printf("Enter the size of array:");
    scanf("%d",&n);
    char ch[n];
    
    //insert the element
    printf("Enter the element in array:\n");
    for(i=0; i<n; i++){
        scanf("%c\n",&ch[i]);
        }
        //display the array
    printf("Display the elemnt of array: ");
    for(j=0; j<=n; ++j){
        printf("%c ",ch[j]);
        }
        
        return 0;
    }