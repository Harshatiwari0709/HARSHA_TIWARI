Payload format

{
    "device_id" : 1,
    "device_type" : "RPI",
    "sensor_data" : {
            "temperature" : 45,
            "humidity" : 85
    }
}

# Boto3 Docs

https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html


## for more details refer swagger docs