
var uname = "Pranali"

function greet(){
    document.write("Hello " + uname)
}