from excerise_module_fun_day3 import add_fun,str_upper,salary,height,dollar,travel



add_fun(3)

print(str_upper())

print(salary())

height(150)

dollar(6)

travel('a','b',2)


