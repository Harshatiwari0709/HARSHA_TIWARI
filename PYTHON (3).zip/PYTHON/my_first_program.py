x = "Pranali"
y = "Aishwarya"

print(f'Hello {x}')
print(f'Hello and welcome to my world of coding 😍❤🤣😂😊❤🤣❤❤❤❤ {y}')
print("Hello World")
print(f'wakeup harsha 😴😴🥱🥱😴😴😴😴😴😴😴😴😴😴🥱🥱😴🥱')
