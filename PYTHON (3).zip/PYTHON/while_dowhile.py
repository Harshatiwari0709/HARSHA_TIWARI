# Solve the following using either while/do while loops

# 1) Take a number from the user and print sum from 1 to that number 

# num=int(input("Enter the number:"))
# sum = 0
# num1 =1
# while(num>=num1):
#   sum = sum + num1
#   num1 =num1+1
#   print(sum)
  
# 2) Take a number from the user and print all Odd numbers from 1 to that number 

# num = int(input("Enter the number: "))
# num1 = 1
# while(num>num1):
#   if(num1%2 != 0):
#     print(num1)
#   num1 +=1
    
# 3) Take a number from the user and print all Even numbers from 1 to that number 

num = int(input("Enter the number: "))
num1 = 1
while(num>num1):
  if(num1%2 == 0):
    print(num1)
  num1 +=1

   
   


